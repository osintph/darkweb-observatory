#!/usr/bin/env python3
"""
News Feed Refresher
Fetches latest cybersecurity news and updates the dashboard feed
Can be called on-demand or via cron
"""

import feedparser
import json
import datetime
import re
from datetime import datetime as dt

OUTPUT_FILE = "/var/www/html/news_feed.json"

# RSS/Atom feeds for cybersecurity news
NEWS_SOURCES = [
    {
        'name': 'The Hacker News',
        'url': 'https://feeds.feedburner.com/TheHackersNews',
        'category': 'General'
    },
    {
        'name': 'Krebs on Security',
        'url': 'https://krebsonsecurity.com/feed/',
        'category': 'Investigation'
    },
    {
        'name': 'Dark Reading',
        'url': 'https://www.darkreading.com/rss_simple.asp',
        'category': 'Enterprise'
    },
    {
        'name': 'Threatpost',
        'url': 'https://threatpost.com/feed/',
        'category': 'Threat Intel'
    },
    {
        'name': 'Bleeping Computer',
        'url': 'https://www.bleepingcomputer.com/feed/',
        'category': 'General'
    },
    {
        'name': 'Schneier on Security',
        'url': 'https://www.schneier.com/blog/atom.xml',
        'category': 'Cryptography'
    },
    {
        'name': 'SANS Internet Storm Center',
        'url': 'https://isc.sans.edu/rssfeed.xml',
        'category': 'Threat Intel'
    },
    {
        'name': 'Security Affairs',
        'url': 'https://securityaffairs.com/feed',
        'category': 'General'
    },
    {
        'name': 'Recorded Future',
        'url': 'https://www.recordedfuture.com/feed',
        'category': 'Threat Intel'
    },
    {
        'name': 'CISA Alerts',
        'url': 'https://www.cisa.gov/cybersecurity-advisories/all.xml',
        'category': 'Government'
    }
]

def clean_html(text):
    """Remove HTML tags from text"""
    if not text:
        return ""
    text = re.sub(r'<[^>]+>', '', text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()

def fetch_news():
    """Fetch news from all sources"""
    print(f"[*] Refreshing news feed from {len(NEWS_SOURCES)} sources...")
    
    all_articles = []
    
    for source in NEWS_SOURCES:
        try:
            print(f"  [*] Fetching from {source['name']}...")
            feed = feedparser.parse(source['url'])
            
            if feed.bozo:  # Feed has errors
                print(f"    [!] Warning: Feed may have issues")
            
            for entry in feed.entries[:10]:  # Get top 10 from each source
                # Extract published date
                published = entry.get('published', entry.get('updated', 'Unknown'))
                try:
                    # Try to parse date
                    if hasattr(entry, 'published_parsed') and entry.published_parsed:
                        published = dt(*entry.published_parsed[:6]).isoformat()
                    elif hasattr(entry, 'updated_parsed') and entry.updated_parsed:
                        published = dt(*entry.updated_parsed[:6]).isoformat()
                except:
                    pass
                
                article = {
                    'title': clean_html(entry.get('title', 'No Title')),
                    'link': entry.get('link', '#'),
                    'description': clean_html(entry.get('summary', entry.get('description', 'No description available')))[:300],
                    'published': published,
                    'source': source['name'],
                    'category': source['category']
                }
                
                all_articles.append(article)
            
            print(f"    [+] Retrieved {len(feed.entries[:10])} articles")
            
        except Exception as e:
            print(f"    [!] Error fetching from {source['name']}: {e}")
            continue
    
    # Sort by date (most recent first)
    try:
        all_articles.sort(key=lambda x: x['published'], reverse=True)
    except:
        pass  # If sorting fails, keep original order
    
    # Save to JSON
    output = {
        'generated': datetime.datetime.now().isoformat(),
        'total_articles': len(all_articles),
        'sources': len(NEWS_SOURCES),
        'articles': all_articles[:100]  # Keep top 100
    }
    
    try:
        with open(OUTPUT_FILE, 'w') as f:
            json.dump(output, f, indent=2)
        print(f"[+] News feed updated: {len(all_articles)} articles")
        print(f"[+] Saved to: {OUTPUT_FILE}")
        return True
    except Exception as e:
        print(f"[!] Failed to save news feed: {e}")
        return False

if __name__ == "__main__":
    fetch_news()
