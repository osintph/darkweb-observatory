#!/bin/bash
#
# Installation script for new dashboard features:
# 1. On-Demand Deep Scanner
# 2. News Feed Refresh Button
#

set -e

echo "[*] Installing new dashboard features..."

# Create CGI directory
echo "[*] Creating CGI directory..."
sudo mkdir -p /var/www/html/cgi-bin

# Copy scripts
echo "[*] Copying scripts..."
sudo cp on_demand_scan.py /var/www/html/cgi-bin/
sudo cp refresh_news.py /var/www/html/cgi-bin/
sudo cp on_demand_scan_cgi.py /var/www/html/cgi-bin/on_demand_scan.py
sudo cp refresh_news_cgi.py /var/www/html/cgi-bin/refresh_news.py

# Make executable
echo "[*] Setting permissions..."
sudo chmod +x /var/www/html/cgi-bin/*.py

# Check if CGI module is enabled
echo "[*] Checking Apache CGI module..."
if ! apache2ctl -M 2>/dev/null | grep -q cgi_module; then
    echo "    [!] Enabling CGI module..."
    sudo a2enmod cgi
    RESTART_NEEDED=true
else
    echo "    [+] CGI module already enabled"
fi

# Create Apache CGI configuration if needed
CGI_CONF="/etc/apache2/conf-available/cgi-enabled.conf"
if [ ! -f "$CGI_CONF" ]; then
    echo "[*] Creating CGI configuration..."
    sudo tee "$CGI_CONF" > /dev/null <<'EOF'
<Directory "/var/www/html/cgi-bin">
    Options +ExecCGI
    AddHandler cgi-script .py
    Require all granted
</Directory>

ScriptAlias /cgi-bin/ /var/www/html/cgi-bin/
EOF
    sudo a2enconf cgi-enabled
    RESTART_NEEDED=true
fi

# Restart Apache if needed
if [ "$RESTART_NEEDED" = true ]; then
    echo "[*] Restarting Apache..."
    sudo systemctl restart apache2
    echo "    [+] Apache restarted"
fi

# Test if feedparser is installed
echo "[*] Checking Python dependencies..."
if ! python3 -c "import feedparser" 2>/dev/null; then
    echo "    [!] Installing feedparser..."
    pip3 install feedparser --break-system-packages
else
    echo "    [+] feedparser already installed"
fi

# Initial news feed generation
echo "[*] Generating initial news feed..."
python3 refresh_news.py

echo ""
echo "[✓] Installation complete!"
echo ""
echo "Next steps:"
echo "1. Add the HTML/CSS/JS snippets from dashboard_additions.html to your advanced_scanner.py"
echo "2. Run your scanner to regenerate the dashboard"
echo "3. Test the features at http://localhost/"
echo ""
echo "Features added:"
echo "  • On-Demand Deep Scanner - Scan any .onion URL on demand"
echo "  • News Refresh Button - Refresh cybersecurity news feed"
echo ""
